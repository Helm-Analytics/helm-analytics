# Helm Analytics Python SDK

Official Python middleware for [Helm Analytics](https://helm-analytics.com). Track server-side events, verify traffic quality, and bypass ad-blockers by ingesting data directly from your backend.

## Installation

```bash
pip install helm-analytics
```

## Quick Start (FastAPI)

```python
from fastapi import FastAPI
from starlette.middleware.base import BaseHTTPMiddleware
from helm_analytics import HelmAnalytics

app = FastAPI()

# Initialize Helm
helm = HelmAnalytics(site_id="YOUR_SITE_ID_HERE")

# Register Middleware
app.add_middleware(BaseHTTPMiddleware, dispatch=helm.fastapi_dispatch)

@app.get("/")
def home():
    return {"message": "Hello World"}
```

## Shield Mode (Blocking)

Helm can actively block malicious requests (e.g. from banned IPs or countries) before they hit your logic.

```python
# Flask
app.before_request(helm.flask_middleware(shield=True))

# FastAPI
app.add_middleware(BaseHTTPMiddleware, dispatch=helm.fastapi_middleware(shield=True))
```

## Custom Event Tracking

Track meaningful milestones like signups, payments, or file exports:

```python
@app.post("/signup")
def signup(request):
    # ... logic ...
    helm.track_event(request, "user_signup", {"plan": "premium"})
    return {"status": "ok"}
```

## Session Stitching

To link server-side events back to the browser session, pass the `sessionId` from your frontend (stored in `sessionStorage` as `helm_session_id`) in the `X-Helm-Session-Id` header of your API requests.

## Features

- **Non-blocking**: Uses background threads to send data without slowing down your app.
- **Shield Mode**: Synchronously queries Helm to block threats at the edge.
- **Custom Events**: Track business milestones beyond simple pageviews.
- **Session Stitching**: Link server-side actions to web sessions via headers.
- **Fail-safe**: Failures in tracking do not crash your application.

## Configuration

You can also set the Site ID via environment variable:

```bash
export HELM_SITE_ID="your-uuid"
```
