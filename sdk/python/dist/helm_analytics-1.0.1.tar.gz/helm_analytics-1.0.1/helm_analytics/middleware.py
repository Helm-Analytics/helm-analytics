import threading
import requests
import os
import json
import logging

logger = logging.getLogger("helm-analytics")

class HelmAnalytics:
    def __init__(self, site_id=None, api_url="https://api-sentinel.getmusterup.com/track"):
        self.site_id = site_id or os.getenv('HELM_SITE_ID')
        self.api_url = api_url
        
        if not self.site_id:
            logger.warning("HelmAnalytics: No Site ID provided. Tracking will be disabled.")

    def _send_payload(self, payload):
        if not self.site_id:
            return
            
        def _post():
            try:
                requests.post(
                    self.api_url, 
                    json=payload, 
                    headers={'Content-Type': 'application/json'},
                    timeout=5
                )
            except Exception as e:
                logger.debug(f"HelmAnalytics Error: {e}")

        # Fire and forget
        threading.Thread(target=_post).start()

    def track(self, request, event_type="pageview", metadata=None):
        """
        Generic track method. Supports Flask, Django, and FastAPI/Starlette requests.
        """
        try:
            # 1. URL
            if hasattr(request, 'url'):
                url = str(request.url)
            else:
                url = str(request)
            
            # 2. Headers
            headers = getattr(request, 'headers', {})
            
            # 3. IP
            # FastAPI/Starlette: request.client.host
            if hasattr(request, 'client') and hasattr(request.client, 'host'):
                ip = request.client.host
            elif hasattr(request, 'remote_addr'):
                ip = request.remote_addr
            else:
                ip = ''
            
            # Trust X-Forwarded-For
            # Headers in Starlette are case-insensitive mutable mapping usually, but let's be safe
            if hasattr(headers, 'get'):
                x_fwd = headers.get('x-forwarded-for') or headers.get('X-Forwarded-For')
                if x_fwd:
                    ip = x_fwd.split(',')[0].strip()
            
            user_agent = headers.get('user-agent') if hasattr(headers, 'get') else ''
            referrer = headers.get('referer') if hasattr(headers, 'get') else ''
            
            # Fallback for dict-like headers
            if not user_agent and isinstance(headers, dict):
                 user_agent = headers.get('User-Agent', '')
            if not referrer and isinstance(headers, dict):
                 referrer = headers.get('Referer', '')

            payload = {
                "siteId": self.site_id,
                "url": url,
                "clientIp": ip,
                "userAgent": user_agent,
                "referrer": referrer,
                "eventType": event_type,
                "screenWidth": 0,
                "isServerSide": True
            }
            if metadata:
                payload.update(metadata)
                
            self._send_payload(payload)
            
        except Exception as e:
            logger.error(f"HelmAnalytics Tracking Failed: {e}")

    async def fastapi_dispatch(self, request, call_next):
        """
        FastAPI/Starlette dispatch function.
        Usage: app.add_middleware(BaseHTTPMiddleware, dispatch=helm.fastapi_dispatch)
        """
        response = await call_next(request)
        self.track(request)
        return response
